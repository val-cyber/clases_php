import { getEstudaintes } from "./API.js";

addEventListener('DOMContentLoaded', cargarEstudiantes);

async function cargarEstudiantes(){
    const tablaEstudiantes = document.querySelector('#tabla');
    const estudiantes = await getEstudaintes();
    console.log(estudiantes);
    
    estudiantes.forEach(element => {
        const {id, nombre, especialidad, imagen} = element;
        tablaEstudiantes.innerHTML+=`
        
        <tr class="cards" 
        nombre="${element.id}"
        imagen="${element.imagen}"
        nombre="${element.nombre}"
        edad="${element.edad}"
        promedio="${element.promedio}"
        nivelCAmpus="${element.nivelCAmpus}"
        nivelIngles="${element.nivelIngles}"
        especialidad="${element.especialidad}"
        direccion="${element.direccion}"
        celular="${element.celular}"
        ingles="${element.ingles}"
        Ser="${element.Ser}"
        Review="${element.Review}"
        Skills="${element.Skills}"
        Asitencia="${element.Asitencia}"
        
        
        >
        <th scope="row" id="${element.id}">${id}</th>
        <td id="${element.id}">${nombre}</td>
        <td id="${element.id}">${especialidad}</td>

        <td id="${element.id}"><img id="${element.id}"src="images/${imagen}"></td>

        <td id="${element.id}"><button id="${element.id}" type="button" class="btn btn-info">Notas</button></td>
        </tr>
        
        
        `
    });
} 
detalles()

function detalles(){
    const tablaEstudiantes = document.querySelector('#tabla');
    tablaEstudiantes.addEventListener('click', e=> {
        console.log(e.target);
        if(e.target.getAttribute('id')){
            const atributos = e.target.getAttribute('id');
            const elemento = document.getElementById(atributos);
            const padre = elemento.parentNode;
            console.log(padre);


            const imagen = padre.getAttribute('imagen');
            const nombre = padre.getAttribute('nombre');
            const edad = padre.getAttribute('edad');
            const promedio = padre.getAttribute('promedio');
            const nivelCAmpus = padre.getAttribute('nivelCAmpus');
            const nivelIngles = padre.getAttribute('nivelIngles');
            const especialidad = padre.getAttribute('especialidad');
            const direccion = padre.getAttribute('direccion');
            const celular = padre.getAttribute('celular');
            const ingles = padre.getAttribute('ingles');
            const Ser = padre.getAttribute('Ser');
            const Review = padre.getAttribute('Review');
            const Skills = padre.getAttribute('Skills');
            const Asitencia = padre.getAttribute('Asitencia');

            const detalles = document.querySelector('#detalles');
            detalles.innerHTML = ``;
            detalles.innerHTML = `
            
            <div class="containerDetalles">
            <div class="datos">
                <div class="d-flex"><img src="images/${imagen}" alt="" class="m-2">
                <button class="btn btn-danger" style ="height: 40px;">Eliminar</button></div>
                <h5>${nombre}</h5>
                <h5>edad: ${edad}</h5>
                <h5>promedio:${promedio}</h5>
                <h5>nivel: ${nivelCAmpus}</h5>
                <h5>ingles ${nivelIngles}</h5>
                <h5>especialidad ${especialidad}</h5>
                <h5>direccion ${direccion}</h5>
                
    
                <h5 style="background-color: #DB005B; border-radius:80px; padding:7px;">celular : ${celular}</h5>
                
            </div>
            </div>
            <div id="" class=""> </div>
            `;
        }
    })

}